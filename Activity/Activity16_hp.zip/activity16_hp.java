//Harrison Pierce
//11/20/2017
//This program asks the user for their name employee number and specialy and prints
// the result using superclass and child method.

import java.util.Scanner;
public class activity16_hp
{

    public static void main(String[] args) 
    {
        String name;
        int EmpNum;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Name: ");
        name = input.nextLine();
        
        System.out.println("Employee Number: ");
        EmpNum = input.nextInt();
        
        hospitalemployee hospemp = new hospitalemployee(name, EmpNum);
        
        System.out.println("Enter specialty: ");
        String specialty = input.nextLine(); 
        
        doctor doc = new doctor(name, EmpNum, specialty);
        
        System.out.println(hospemp.work);
        System.out.println(doc.diagnose);
        

    }
}
