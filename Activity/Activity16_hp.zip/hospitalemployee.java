//Harrison Pierce
//11/20/2017
//This program 
import java.util.Scanner;
public class hospitalemployee
{
        int EmpNum;
        String name;
        
        public hospitalemployee(String nam, int num1){
            EmpNum = num1;
            name = nam;
        }

        public void setName(String nam){
        name = nam;
}
    
        public void setNumber(int num1){
        EmpNum = num1;
    
}
        public String getName(){
            return name;
}
        public int getNumber(){
            return EmpNum;
        }
        
        
        public void work(String name){
            System.out.println(name + " works for the hospital.");

        
        }
        
    }
