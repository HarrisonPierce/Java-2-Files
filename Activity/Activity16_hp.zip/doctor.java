
public class doctor extends hospitalemployee{
    
    int empnum;
    String name;
    String specialty;
    
    
    public doctor(String nam, int num1, String special1){
    empnum = num1;
    name = nam;
    special1 = specialty;
    hospitalemployee hospemp = new hospitalemployee(name, empnum);
    }

        public void setSpecialty(String special){
        specialty = special;
        }
        
        public String getSpecialty(){
           return specialty;
        }
        
        
        public void diagnose(String name,String  specialty){
        System.out.println(name + "is a(n) "+specialty);
    }
}
